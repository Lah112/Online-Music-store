CREATE TABLE feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customerName VARCHAR(100),
    email VARCHAR(100),
    feedbackMessage TEXT
);
